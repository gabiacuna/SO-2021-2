Gabriela Acuña  (p201) rol: 201973504-5
Tomas Morales   (p201) rol: 201973611-6

Los archivos se llaman 
El archivo para la primera seccion de la tarea, se llama laberinto.c y para la segunda seccion, se llama buscar.c .

- Se asume que en el directorio actual no existe una carpeta llamada 'Laberinto', si es así, el programa no se ejecutara.

Cada archivo se compila por separado,

Para compilar y ejecutar laberinto.c:

make Lab

Para compilar y ejecutar buscar.c:

make Bus

Para borrar los ejecutables generados:

make clean